#include "Bank.h"
#include "Economy.h"

Bank::Bank(Economy eco): totalGold(5000), interestRate(0.15), corruptionLevel(20) {}

// Grants loan to kingdom (returns false if bank lacks funds)
bool Bank::grantLoan(Economy& economy, int amount) {
    if (amount > totalGold / 2) {
        cout << "Loan DENIED! Bank reserves insufficient." << endl;
        return false;
    }

    int repayment = amount * (1 + interestRate);
    economy.allocateBudget(amount, 0);  // Add to kingdom's treasury
    totalGold -= amount;

    cout << "Loan APPROVED: " << amount << " gold ("
        << interestRate * 100 << "% interest)" << endl;
    return true;
}

// Random chance to detect corruption
void Bank::detectFraud(Economy& economy) {
    if (rand() % 100 < corruptionLevel) {
        int stolenAmount = 300;
        economy.allocateBudget(-stolenAmount, 0);  // Deduct from treasury
        cout << "FRAUD DETECTED! Recovered " << stolenAmount << " gold." << endl;
    }
}

// Adjusts rates based on inflation
void Bank::adjustInterestRates(int inflation) {
    interestRate = 0.1 + (inflation / 100.0);  // Higher inflation = higher rates
    cout << "New interest rate: " << interestRate * 100 << "%" << endl;
}

// New: Bank run event (people withdraw gold)
void Bank::triggerBankRun(Economy& economy) {
    if (totalGold < economy.getTreasury() / 2) {
        int lostGold = totalGold / 3;
        totalGold -= lostGold;
        cout << "BANK RUN! Lost " << lostGold << " gold reserves." << endl;
    }
}

// Getters
int Bank::getGoldReserves() { return totalGold; }
float Bank::getInterestRate() { return interestRate; }